import express from 'express';
import pool from '../db.js';

const router = express.Router();

// GET all blogs
router.get('/', async (req, res) => {
    try {
        let query = 'SELECT * FROM blogs';
        const params = [];
        if (req.query.status) {
            query += ' WHERE status = ?';
            params.push(req.query.status);
        }
        query += ' ORDER BY created_at DESC';
        const [rows] = await pool.execute(query, params);
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// GET blog by slug
router.get('/:slug', async (req, res) => {
    try {
        const [rows] = await pool.execute('SELECT * FROM blogs WHERE slug = ?', [req.params.slug]);
        if (rows.length === 0) return res.status(404).json({ error: 'Blog not found' });
        res.json(rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// POST create a blog
router.post('/', async (req, res) => {
    try {
        const {
            title, slug, excerpt = '', content = '', category = '',
            status = 'draft', image_url = null, author = 'Admin', tags = ''
        } = req.body;

        const finalSlug = slug || title.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');

        const [result] = await pool.execute(
            `INSERT INTO blogs (title, slug, excerpt, content, category, status, image_url, author, tags)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [title, finalSlug, excerpt, content, category, status, image_url, author, tags]
        );
        const [rows] = await pool.execute('SELECT * FROM blogs WHERE id = ?', [result.insertId]);
        res.status(201).json(rows[0]);
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
});

// PUT update a blog
router.put('/:id', async (req, res) => {
    try {
        const { title, ...rest } = req.body;
        const updateData = title ? { title, ...rest } : rest;
        const fields = Object.keys(updateData).map(k => `${k} = ?`).join(', ');
        const values = [...Object.values(updateData), req.params.id];
        await pool.execute(`UPDATE blogs SET ${fields} WHERE id = ?`, values);
        const [rows] = await pool.execute('SELECT * FROM blogs WHERE id = ?', [req.params.id]);
        if (rows.length === 0) return res.status(404).json({ error: 'Blog not found' });
        res.json(rows[0]);
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
});

// DELETE a blog
router.delete('/:id', async (req, res) => {
    try {
        const [result] = await pool.execute('DELETE FROM blogs WHERE id = ?', [req.params.id]);
        if (result.affectedRows === 0) return res.status(404).json({ error: 'Blog not found' });
        res.json({ message: 'Deleted successfully' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

export default router;
