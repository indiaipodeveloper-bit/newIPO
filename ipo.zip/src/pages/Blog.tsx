import Header from "@/components/Header";
import Footer from "@/components/Footer";
import SEOHead from "@/components/SEOHead";
import { blogPosts } from "@/data/mockData";
import { Calendar, Clock, ArrowRight } from "lucide-react";
import { motion } from "framer-motion";

import blog1 from "@/assets/blog-1.jpg";
import blog2 from "@/assets/blog-2.jpg";
import blog3 from "@/assets/blog-3.jpg";

const blogImages: Record<string, string> = {
  "blog-1": blog1,
  "blog-2": blog2,
  "blog-3": blog3,
};

const Blog = () => {
  return (
    <div className="min-h-screen">
      <SEOHead title="Blog" description="IPO insights, market analysis, GMP updates, and investment guides from IndiaIPO experts." keywords="IPO blog, IPO news, GMP updates, market analysis" />
      <Header />
      <main>
        <section className="gradient-navy py-16">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-3xl md:text-4xl font-bold font-heading text-primary-foreground mb-3">
              IPO <span className="text-gradient-gold">Blog</span>
            </h1>
            <p className="text-primary-foreground/60 max-w-lg mx-auto">
              Expert insights, market analysis, and IPO guides.
            </p>
          </div>
        </section>

        <section className="py-12 bg-background">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {blogPosts.map((post, idx) => (
                <motion.article
                  key={post.id}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.1 }}
                  className="bg-card border border-border rounded-2xl overflow-hidden hover:border-primary/30 hover:shadow-xl transition-all duration-300 group cursor-pointer"
                >
                  <div className="relative h-52 overflow-hidden">
                    <img
                      src={blogImages[post.image]}
                      alt={post.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-foreground/40 to-transparent" />
                    <span className="absolute top-4 left-4 bg-accent text-accent-foreground text-xs font-bold px-3 py-1 rounded-lg">
                      {post.category}
                    </span>
                  </div>
                  <div className="p-6">
                    <h2 className="text-lg font-bold font-heading text-foreground mb-3 group-hover:text-primary transition-colors">{post.title}</h2>
                    <p className="text-sm text-muted-foreground line-clamp-3 mb-4">{post.excerpt}</p>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1"><Calendar className="h-3 w-3" />{post.date}</span>
                        <span className="flex items-center gap-1"><Clock className="h-3 w-3" />{post.readTime}</span>
                      </div>
                      <span className="text-sm font-semibold text-primary group-hover:translate-x-1 transition-transform inline-flex items-center">
                        Read <ArrowRight className="ml-1 h-3.5 w-3.5" />
                      </span>
                    </div>
                  </div>
                </motion.article>
              ))}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Blog;
