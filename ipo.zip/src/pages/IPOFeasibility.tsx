import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import SEOHead from "@/components/SEOHead";
import { toast } from "sonner";
import { CheckCircle, ArrowRight, Building2, TrendingUp, Shield } from "lucide-react";
import { motion } from "framer-motion";

const IPOFeasibility = () => {
  const [formData, setFormData] = useState({
    companyName: "",
    contactPerson: "",
    email: "",
    phone: "",
    sector: "",
    revenue: "",
    netProfit: "",
    yearsInBusiness: "",
    ipoType: "",
    message: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success("Your IPO feasibility request has been submitted! Our team will contact you within 24 hours.");
    setFormData({
      companyName: "", contactPerson: "", email: "", phone: "",
      sector: "", revenue: "", netProfit: "", yearsInBusiness: "", ipoType: "", message: "",
    });
  };

  const handleChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  return (
    <div className="min-h-screen">
      <SEOHead
        title="Check IPO Feasibility"
        description="Submit your company details for a free IPO feasibility assessment. Our experts will evaluate your readiness for SME or Mainline IPO."
        keywords="IPO feasibility, IPO consultation, SME IPO eligibility, Mainline IPO check"
      />
      <Header />
      <main>
        {/* Hero */}
        <section className="bg-primary py-16 lg:py-20">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center">
              <motion.h1
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-3xl md:text-5xl font-bold font-heading text-primary-foreground mb-4"
              >
                Check Your <span className="text-accent">IPO Feasibility</span>
              </motion.h1>
              <p className="text-primary-foreground/70 text-lg max-w-xl mx-auto">
                Get a free assessment of your company's readiness for an Initial Public Offering. Our SEBI-registered experts will guide you.
              </p>
            </div>
          </div>
        </section>

        {/* Benefits */}
        <section className="py-12 bg-secondary/30">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[
                { icon: <CheckCircle className="h-6 w-6" />, title: "Free Assessment", desc: "No cost, no obligation IPO readiness evaluation" },
                { icon: <Shield className="h-6 w-6" />, title: "SEBI Compliant", desc: "Guidance aligned with latest SEBI regulations" },
                { icon: <TrendingUp className="h-6 w-6" />, title: "Expert Advisory", desc: "15+ years of IPO consultancy experience" },
              ].map((item) => (
                <div key={item.title} className="flex items-start gap-4 bg-card rounded-xl p-5 border border-border">
                  <div className="w-12 h-12 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0">
                    {item.icon}
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground">{item.title}</h3>
                    <p className="text-sm text-muted-foreground">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Form */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto">
              <div className="bg-card border border-border rounded-2xl p-8 md:p-10">
                <h2 className="text-2xl font-bold font-heading text-foreground mb-2">Company Details</h2>
                <p className="text-muted-foreground mb-8">Fill in the form below and our team will evaluate your IPO eligibility.</p>

                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium text-foreground mb-1.5 block">Company Name *</label>
                      <Input required value={formData.companyName} onChange={(e) => handleChange("companyName", e.target.value)} placeholder="ABC Pvt Ltd" />
                    </div>
                    <div>
                      <label className="text-sm font-medium text-foreground mb-1.5 block">Contact Person *</label>
                      <Input required value={formData.contactPerson} onChange={(e) => handleChange("contactPerson", e.target.value)} placeholder="Full Name" />
                    </div>
                    <div>
                      <label className="text-sm font-medium text-foreground mb-1.5 block">Email *</label>
                      <Input required type="email" value={formData.email} onChange={(e) => handleChange("email", e.target.value)} placeholder="you@company.com" />
                    </div>
                    <div>
                      <label className="text-sm font-medium text-foreground mb-1.5 block">Phone *</label>
                      <Input required value={formData.phone} onChange={(e) => handleChange("phone", e.target.value)} placeholder="+91 98765 43210" />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium text-foreground mb-1.5 block">Industry/Sector *</label>
                      <Select value={formData.sector} onValueChange={(v) => handleChange("sector", v)}>
                        <SelectTrigger><SelectValue placeholder="Select sector" /></SelectTrigger>
                        <SelectContent>
                          {["Technology", "Healthcare", "Finance", "Manufacturing", "Energy", "Real Estate", "FMCG", "Automobile", "Infrastructure", "Other"].map((s) => (
                            <SelectItem key={s} value={s}>{s}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-foreground mb-1.5 block">IPO Type *</label>
                      <Select value={formData.ipoType} onValueChange={(v) => handleChange("ipoType", v)}>
                        <SelectTrigger><SelectValue placeholder="Select IPO type" /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="sme">SME IPO (BSE SME / NSE Emerge)</SelectItem>
                          <SelectItem value="mainline">Mainline IPO (BSE / NSE)</SelectItem>
                          <SelectItem value="fpo">Follow-on Public Offer (FPO)</SelectItem>
                          <SelectItem value="unsure">Not Sure - Need Guidance</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <label className="text-sm font-medium text-foreground mb-1.5 block">Annual Revenue (₹ Cr)</label>
                      <Input value={formData.revenue} onChange={(e) => handleChange("revenue", e.target.value)} placeholder="e.g. 50" />
                    </div>
                    <div>
                      <label className="text-sm font-medium text-foreground mb-1.5 block">Net Profit (₹ Cr)</label>
                      <Input value={formData.netProfit} onChange={(e) => handleChange("netProfit", e.target.value)} placeholder="e.g. 5" />
                    </div>
                    <div>
                      <label className="text-sm font-medium text-foreground mb-1.5 block">Years in Business</label>
                      <Input value={formData.yearsInBusiness} onChange={(e) => handleChange("yearsInBusiness", e.target.value)} placeholder="e.g. 8" />
                    </div>
                  </div>

                  <div>
                    <label className="text-sm font-medium text-foreground mb-1.5 block">Additional Information</label>
                    <Textarea value={formData.message} onChange={(e) => handleChange("message", e.target.value)} placeholder="Tell us about your company, growth plans, and why you're considering an IPO..." rows={4} />
                  </div>

                  <Button type="submit" size="lg" className="w-full bg-primary text-primary-foreground hover:bg-primary/90 font-semibold text-base">
                    Submit for Free Assessment
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>

                  <p className="text-xs text-muted-foreground text-center">
                    By submitting this form, you agree to our privacy policy. Your information will be kept confidential.
                  </p>
                </form>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default IPOFeasibility;
