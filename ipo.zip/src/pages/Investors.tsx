import Header from "@/components/Header";
import Footer from "@/components/Footer";

import SEOHead from "@/components/SEOHead";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Users, TrendingUp, Shield, CheckCircle, ArrowRight } from "lucide-react";

const benefits = [
  { icon: TrendingUp, title: "Expert Market Analysis", desc: "Access real-time GMP data, subscription status, and listing performance analysis." },
  { icon: Shield, title: "SEBI Compliant", desc: "All our advisory services are fully compliant with SEBI regulations." },
  { icon: Users, title: "Dedicated Support", desc: "Get personalized IPO investment guidance from our expert team." },
  { icon: CheckCircle, title: "Track Record", desc: "450+ successful IPO listings with 98% success rate." },
];

const Investors = () => {
  return (
    <div className="min-h-screen">
      <SEOHead title="Investors" description="IPO investment tools, GMP tracking, subscription data, and expert analysis for retail and institutional investors." />
      <Header />
      <main>
        <section className="bg-primary py-16">
          <div className="container mx-auto px-4 text-center">
            <motion.h1 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-3xl md:text-5xl font-bold font-heading text-primary-foreground mb-4">
              For <span className="text-accent">Investors</span>
            </motion.h1>
            <p className="text-primary-foreground/70 max-w-xl mx-auto">
              Everything you need to make informed IPO investment decisions.
            </p>
          </div>
        </section>

        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
              {benefits.map((item, idx) => {
                const Icon = item.icon;
                return (
                  <motion.div
                    key={idx}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ delay: idx * 0.1 }}
                    viewport={{ once: true }}
                    className="bg-card border border-border rounded-xl p-6 text-center hover:border-primary/30 transition-colors"
                  >
                    <div className="w-14 h-14 rounded-full bg-primary/10 text-primary flex items-center justify-center mx-auto mb-4">
                      <Icon className="h-6 w-6" />
                    </div>
                    <h3 className="font-semibold text-foreground mb-2">{item.title}</h3>
                    <p className="text-sm text-muted-foreground">{item.desc}</p>
                  </motion.div>
                );
              })}
            </div>

            <div className="text-center">
              <h2 className="text-2xl font-bold font-heading text-foreground mb-4">Quick Links for Investors</h2>
              <div className="flex flex-wrap justify-center gap-3">
                {[
                  { label: "IPO Calendar", href: "/ipo-calendar" },
                  { label: "GMP Tracker", href: "/#gmp" },
                  { label: "IPO Calculator", href: "/ipo-calculator" },
                  { label: "IPO Reports", href: "/reports" },
                  { label: "Blog", href: "/blog" },
                ].map((link) => (
                  <Button key={link.label} variant="outline" className="border-primary/30 text-primary hover:bg-primary/5" asChild>
                    <Link to={link.href}>
                      {link.label}
                      <ArrowRight className="h-3.5 w-3.5 ml-1" />
                    </Link>
                  </Button>
                ))}
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
      
    </div>
  );
};

export default Investors;
