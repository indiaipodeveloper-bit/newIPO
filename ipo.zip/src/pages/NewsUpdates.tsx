import Header from "@/components/Header";
import Footer from "@/components/Footer";

import SEOHead from "@/components/SEOHead";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { FileText, ChevronRight, Newspaper, Youtube } from "lucide-react";

const newsItems = [
  { title: "Sensex Crosses 85,000 Mark for First Time", date: "March 4, 2026", category: "Markets" },
  { title: "RBI Maintains Repo Rate at 6.25% in March Policy", date: "March 3, 2026", category: "Economy" },
  { title: "SEBI Tightens SME IPO Norms — Key Changes", date: "March 2, 2026", category: "Regulation" },
  { title: "5 IPOs to Watch This Week — Expert Picks", date: "March 1, 2026", category: "IPO" },
  { title: "FII Inflows Turn Positive After 3 Months", date: "Feb 28, 2026", category: "Markets" },
  { title: "Budget 2026 Impact on Capital Markets", date: "Feb 27, 2026", category: "Analysis" },
  { title: "Upcoming Mainline IPOs: March 2026 Preview", date: "Feb 26, 2026", category: "IPO" },
  { title: "How to Evaluate an IPO Before Investing", date: "Feb 25, 2026", category: "Education" },
];

const videoSnaps = [
  { title: "IPO Market Weekly Roundup — Feb 28", views: "12K views" },
  { title: "GMP Analysis: Which IPOs Are Hot?", views: "8K views" },
  { title: "SME IPO Success Story — TechVista Solutions", views: "15K views" },
  { title: "Understanding IPO Allotment Process", views: "22K views" },
];

const NewsUpdates = () => {
  return (
    <div className="min-h-screen">
      <SEOHead title="News & Updates" description="Latest IPO news, market updates, and capital market insights from IndiaIPO." />
      <Header />
      <main>
        <section className="bg-primary py-16">
          <div className="container mx-auto px-4 text-center">
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-3xl md:text-5xl font-bold font-heading text-primary-foreground mb-4"
            >
              News & <span className="text-accent">Updates</span>
            </motion.h1>
            <p className="text-primary-foreground/70 max-w-xl mx-auto">
              Stay informed with the latest from IPO markets, SEBI regulations, and capital market trends.
            </p>
          </div>
        </section>

        <section className="py-12">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Markets & Money Update */}
              <div className="lg:col-span-2">
                <div className="flex items-center gap-2 mb-6">
                  <Newspaper className="h-5 w-5 text-primary" />
                  <h2 className="text-2xl font-bold font-heading text-foreground">Markets & Money Update</h2>
                </div>
                <div className="space-y-4">
                  {newsItems.map((item, idx) => (
                    <motion.div
                      key={idx}
                      initial={{ opacity: 0, x: -10 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      transition={{ delay: idx * 0.05 }}
                      viewport={{ once: true }}
                      className="bg-card border border-border rounded-xl p-4 hover:border-primary/30 transition-colors group cursor-pointer"
                    >
                      <div className="flex items-start justify-between gap-4">
                        <div>
                          <span className="text-[10px] font-semibold text-primary bg-primary/10 px-2 py-0.5 rounded-full">{item.category}</span>
                          <h3 className="font-semibold text-foreground mt-1.5 group-hover:text-primary transition-colors">{item.title}</h3>
                        </div>
                        <span className="text-xs text-muted-foreground shrink-0">{item.date}</span>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>

              {/* IPO & Market Snaps */}
              <div>
                <div className="flex items-center gap-2 mb-6">
                  <Youtube className="h-5 w-5 text-brand-red" />
                  <h2 className="text-xl font-bold font-heading text-foreground">IPO & Market Snaps</h2>
                </div>
                <div className="space-y-3">
                  {videoSnaps.map((vid, idx) => (
                    <div key={idx} className="bg-card border border-border rounded-xl overflow-hidden hover:border-primary/30 transition-colors cursor-pointer group">
                      <div className="h-32 bg-gradient-to-br from-primary/20 to-accent/10 flex items-center justify-center">
                        <div className="w-12 h-12 rounded-full bg-brand-red/90 flex items-center justify-center group-hover:scale-110 transition-transform">
                          <div className="w-0 h-0 border-t-[8px] border-b-[8px] border-l-[14px] border-transparent border-l-primary-foreground ml-1" />
                        </div>
                      </div>
                      <div className="p-3">
                        <h4 className="text-sm font-semibold text-foreground line-clamp-1">{vid.title}</h4>
                        <p className="text-xs text-muted-foreground mt-1">{vid.views}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
      
    </div>
  );
};

export default NewsUpdates;
